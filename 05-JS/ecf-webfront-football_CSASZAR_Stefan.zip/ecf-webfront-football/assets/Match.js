class Match {
    constructor(_footbalFromJson) {
        Object.assign(this, _footbalFromJson);
    }
}

export { Match }